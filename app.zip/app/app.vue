<template>
  <main class="flex min-h-screen font-inter">
    <Menu />

    <div class="grid flex-1 content-start">
      <Page />
      <CardSection />
    </div>
  </main>
</template>