<template>
    <div class="text-4xl bg-secondary w-80 h-screen">
        <h2 class="text-transparent bg-clip-text bg-gradient-to-r from-primary to-linear px-8 py-6 font-bold">TAILWIND</h2>
    </div>
</template>
