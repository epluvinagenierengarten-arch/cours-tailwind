<template>
    <div class="grid grid-rows-[1fr_auto] gap-4 rounded-lg border border-borders bg-white p-4">
        <div>
            <h3 class="text-xs text-secondary-font px-4 py-2 font-bold">
                Create catalog
            </h3>

            <p class="text-xs text-third-font px-4 py-2">
                Create new catalog to add products and generate content.
            </p>
        </div>

        <Boutton/>
    </div>
</template>