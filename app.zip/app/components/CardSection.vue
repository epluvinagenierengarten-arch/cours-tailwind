<template>
    <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4 md:p-8">
        <CardOne />
        <CardTwo />
        <CardThree />
    </section>
</template>
